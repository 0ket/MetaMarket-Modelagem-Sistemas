# Sistema Metamarket

<div style="border: solid 1px; width: fit-content; padding: 0px 20px 20px 20px; border-color: rgba(234,234,234,1)">

  >  For better navigability, read this file in the "Wiki" section of github.
  
#### Contents
- [Overview](#overview)
- [Scope](#scope)
- [Technical Decisions](#technical-decisions)
- [Project Execution](#project-execution)
- [Final Considerations](#final-considerations)
- [Team](#team)
  
</div>

### Overview
***

O sistema MetaMarket tem como principal objetivo automatizar o processo de vendas do supermercado, realizando o cadastro dos produtos do supermercado, o registro do pagamento de compras realizadas pelo cliente, bem como a disponibilização da nota fiscal da compra realizada. Além disso, o sistema irá realizar o somatório das vendas feitas por cada operador de caixa, a fim de contabilizar o lucro total do estabelecimento no fim do mês.
