﻿namespace MetaMarket.Domain.Validation.Entities;

/// <summary>
/// Responsável pelo lançamento de exceções da classe <see cref="User"/> 
/// </summary>
public class UserExceptionValidation : Exception
{

}
