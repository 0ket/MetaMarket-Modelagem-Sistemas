﻿namespace MetaMarket.Domain.Validation.Entities;

/// <summary>
/// vResponsável pelo lançamento de exceções da classe <see cref="Salesperson"/> 
/// </summary>
public class SalespersonExceptionValidation : Exception
{

}
